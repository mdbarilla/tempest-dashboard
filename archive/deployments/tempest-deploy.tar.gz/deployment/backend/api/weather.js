const express = require('express');
const router = express.Router();
const tempestAPI = require('../services/tempest-api');
const db = require('../services/database');

/**
 * GET /api/weather/current
 * Get current weather conditions
 */
router.get('/current', async (req, res) => {
  try {
    const data = await tempestAPI.getCurrentWeather();

    // Store in database for historical tracking
    await db.saveObservation(data);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/forecast
 * Get forecast data
 */
router.get('/forecast', async (req, res) => {
  try {
    const data = await tempestAPI.getForecast();

    res.json({
      success: true,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/complete
 * Get both current conditions and forecast
 */
router.get('/complete', async (req, res) => {
  try {
    const data = await tempestAPI.getCompleteWeather();

    // Check for recent condition corrections
    if (data.current && data.current.timestamp) {
      const correction = await db.getRecentCorrection(data.current.timestamp, 30);

      if (correction) {
        // Apply the correction to the current forecast
        if (data.forecast && data.forecast.current) {
          data.forecast.current.conditions = correction.reported_condition;
          data.forecast.current.corrected = true;
          data.forecast.current.originalCondition = correction.original_condition;
        }
      }
    }

    res.json({
      success: true,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/historical
 * Get historical weather data from database
 * Query params: start (YYYY-MM-DD), end (YYYY-MM-DD), limit
 */
router.get('/historical', async (req, res) => {
  try {
    const { start, end, limit = 1000 } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        success: false,
        error: 'start and end dates are required (YYYY-MM-DD format)'
      });
    }

    const data = await db.getHistoricalData(start, end, parseInt(limit));

    res.json({
      success: true,
      count: data.length,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/stats
 * Get statistical summary for a date range
 */
router.get('/stats', async (req, res) => {
  try {
    const { start, end } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        success: false,
        error: 'start and end dates are required (YYYY-MM-DD format)'
      });
    }

    const stats = await db.getStatistics(start, end);

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/recent
 * Get recent observations for sparklines (last 6 hours)
 */
router.get('/recent', async (req, res) => {
  try {
    const { hours = 6 } = req.query;

    // Get data from the last N hours
    const now = new Date();
    const startTime = new Date(now - hours * 60 * 60 * 1000);
    const start = startTime.toISOString().split('T')[0];
    const end = now.toISOString().split('T')[0];

    const data = await db.getHistoricalData(start, end, 1000);

    // Filter to only last N hours and format for sparklines
    const cutoffTime = Math.floor(startTime.getTime() / 1000);
    const recentData = data.filter(obs => obs.timestamp >= cutoffTime);

    // Sample to approximately 6 data points
    const step = Math.max(1, Math.floor(recentData.length / 6));
    const sampled = recentData.filter((_, i) => i % step === 0).slice(0, 6);

    res.json({
      success: true,
      count: sampled.length,
      data: {
        pressure: sampled.map(d => d.pressure_mb),
        humidity: sampled.map(d => d.humidity),
        wind: sampled.map(d => d.wind_speed),
        precipitation: sampled.map(d => d.precip_today)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * POST /api/weather/correction
 * Submit a condition correction
 */
router.post('/correction', async (req, res) => {
  try {
    const { timestamp, reportedCondition, originalCondition, temperature } = req.body;

    if (!timestamp || !reportedCondition || !originalCondition) {
      return res.status(400).json({
        success: false,
        error: 'timestamp, reportedCondition, and originalCondition are required'
      });
    }

    const result = await db.saveConditionCorrection({
      timestamp,
      reportedCondition,
      originalCondition,
      temperature
    });

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/corrections
 * Get all condition corrections
 */
router.get('/corrections', async (req, res) => {
  try {
    const { limit = 100 } = req.query;
    const corrections = await db.getAllCorrections(parseInt(limit));

    res.json({
      success: true,
      count: corrections.length,
      data: corrections
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;
