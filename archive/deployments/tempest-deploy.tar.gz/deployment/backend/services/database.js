const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

class WeatherDatabase {
  constructor() {
    const dbPath = process.env.DATABASE_PATH || './data/weather.db';
    const dbDir = path.dirname(dbPath);

    // Create data directory if it doesn't exist
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    this.db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('Error opening database:', err);
      } else {
        console.log('📊 Connected to SQLite database');
        this.initializeDatabase();
      }
    });
  }

  /**
   * Initialize database schema
   */
  initializeDatabase() {
    this.db.serialize(() => {
      // Observations table - stores weather readings
      this.db.run(`
        CREATE TABLE IF NOT EXISTS observations (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          timestamp INTEGER NOT NULL UNIQUE,
          temp_celsius REAL,
          temp_fahrenheit REAL,
          feels_like_celsius REAL,
          feels_like_fahrenheit REAL,
          humidity REAL,
          wind_speed REAL,
          wind_gust REAL,
          wind_direction INTEGER,
          pressure_mb REAL,
          pressure_inhg REAL,
          uv_index REAL,
          solar_radiation REAL,
          precip_today REAL,
          precip_last_hour REAL,
          lightning_strikes INTEGER,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create index on timestamp for faster queries
      this.db.run(`
        CREATE INDEX IF NOT EXISTS idx_timestamp
        ON observations(timestamp DESC)
      `);

      // Create index on date for historical queries
      this.db.run(`
        CREATE INDEX IF NOT EXISTS idx_created_at
        ON observations(created_at)
      `);

      // Condition corrections table - stores user-reported corrections
      this.db.run(`
        CREATE TABLE IF NOT EXISTS condition_corrections (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          timestamp INTEGER NOT NULL,
          reported_condition TEXT NOT NULL,
          original_condition TEXT NOT NULL,
          temperature REAL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create index on timestamp for corrections
      this.db.run(`
        CREATE INDEX IF NOT EXISTS idx_corrections_timestamp
        ON condition_corrections(timestamp DESC)
      `);

      console.log('✅ Database schema initialized');
    });
  }

  /**
   * Save weather observation
   */
  saveObservation(data) {
    return new Promise((resolve, reject) => {
      const sql = `
        INSERT OR REPLACE INTO observations (
          timestamp, temp_celsius, temp_fahrenheit,
          feels_like_celsius, feels_like_fahrenheit,
          humidity, wind_speed, wind_gust, wind_direction,
          pressure_mb, pressure_inhg, uv_index,
          solar_radiation, precip_today, precip_last_hour,
          lightning_strikes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const params = [
        data.timestamp,
        data.temperature.celsius,
        data.temperature.fahrenheit,
        data.feelsLike.celsius,
        data.feelsLike.fahrenheit,
        data.humidity,
        data.wind.speed,
        data.wind.gust,
        data.wind.direction,
        data.pressure.mb,
        data.pressure.inHg,
        data.uv,
        data.solarRadiation,
        data.precipitation.today,
        data.precipitation.lastHour,
        data.lightning.strikeCount
      ];

      this.db.run(sql, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({ id: this.lastID, changes: this.changes });
        }
      });
    });
  }

  /**
   * Get historical data for date range
   */
  getHistoricalData(startDate, endDate, limit = 1000) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT * FROM observations
        WHERE DATE(created_at) BETWEEN DATE(?) AND DATE(?)
        ORDER BY timestamp DESC
        LIMIT ?
      `;

      this.db.all(sql, [startDate, endDate, limit], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Get statistical summary for date range
   */
  getStatistics(startDate, endDate) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT
          COUNT(*) as record_count,
          MIN(temp_fahrenheit) as min_temp_f,
          MAX(temp_fahrenheit) as max_temp_f,
          AVG(temp_fahrenheit) as avg_temp_f,
          MIN(temp_celsius) as min_temp_c,
          MAX(temp_celsius) as max_temp_c,
          AVG(temp_celsius) as avg_temp_c,
          AVG(humidity) as avg_humidity,
          MAX(wind_gust) as max_wind_gust,
          AVG(wind_speed) as avg_wind_speed,
          SUM(precip_today) as total_precipitation,
          MAX(uv_index) as max_uv,
          AVG(pressure_mb) as avg_pressure,
          SUM(lightning_strikes) as total_lightning_strikes
        FROM observations
        WHERE DATE(created_at) BETWEEN DATE(?) AND DATE(?)
      `;

      this.db.get(sql, [startDate, endDate], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  /**
   * Get hourly averages for charting
   */
  getHourlyAverages(startDate, endDate) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT
          strftime('%Y-%m-%d %H:00:00', created_at) as hour,
          AVG(temp_fahrenheit) as avg_temp_f,
          AVG(temp_celsius) as avg_temp_c,
          AVG(humidity) as avg_humidity,
          AVG(wind_speed) as avg_wind_speed,
          AVG(pressure_mb) as avg_pressure
        FROM observations
        WHERE DATE(created_at) BETWEEN DATE(?) AND DATE(?)
        GROUP BY hour
        ORDER BY hour
      `;

      this.db.all(sql, [startDate, endDate], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Get daily summary
   */
  getDailySummary(startDate, endDate) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT
          DATE(created_at) as date,
          MIN(temp_fahrenheit) as min_temp_f,
          MAX(temp_fahrenheit) as max_temp_f,
          AVG(temp_fahrenheit) as avg_temp_f,
          AVG(humidity) as avg_humidity,
          MAX(wind_gust) as max_wind_gust,
          AVG(pressure_mb) as avg_pressure,
          MAX(uv_index) as max_uv
        FROM observations
        WHERE DATE(created_at) BETWEEN DATE(?) AND DATE(?)
        GROUP BY date
        ORDER BY date
      `;

      this.db.all(sql, [startDate, endDate], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Save a condition correction
   */
  saveConditionCorrection(data) {
    return new Promise((resolve, reject) => {
      const sql = `
        INSERT INTO condition_corrections (
          timestamp, reported_condition, original_condition, temperature
        ) VALUES (?, ?, ?, ?)
      `;

      const params = [
        data.timestamp,
        data.reportedCondition,
        data.originalCondition,
        data.temperature
      ];

      this.db.run(sql, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({ id: this.lastID });
        }
      });
    });
  }

  /**
   * Get the most recent condition correction within a time window
   */
  getRecentCorrection(timestamp, windowMinutes = 30) {
    return new Promise((resolve, reject) => {
      const windowSeconds = windowMinutes * 60;
      const sql = `
        SELECT * FROM condition_corrections
        WHERE timestamp >= ? AND timestamp <= ?
        ORDER BY created_at DESC
        LIMIT 1
      `;

      this.db.get(sql, [timestamp - windowSeconds, timestamp + windowSeconds], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row || null);
        }
      });
    });
  }

  /**
   * Get all condition corrections for analysis
   */
  getAllCorrections(limit = 100) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT * FROM condition_corrections
        ORDER BY timestamp DESC
        LIMIT ?
      `;

      this.db.all(sql, [limit], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  /**
   * Close database connection
   */
  close() {
    return new Promise((resolve, reject) => {
      this.db.close((err) => {
        if (err) {
          reject(err);
        } else {
          console.log('Database connection closed');
          resolve();
        }
      });
    });
  }
}

module.exports = new WeatherDatabase();
