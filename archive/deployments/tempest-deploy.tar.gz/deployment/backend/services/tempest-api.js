const axios = require('axios');
const NodeCache = require('node-cache');

// Cache settings from environment or defaults
const CACHE_TTL_CURRENT = parseInt(process.env.CACHE_CURRENT_WEATHER) || 60;
const CACHE_TTL_FORECAST = parseInt(process.env.CACHE_FORECAST) || 300;

// Initialize cache
const cache = new NodeCache({
  stdTTL: CACHE_TTL_CURRENT,
  checkperiod: 120
});

class TempestAPI {
  constructor() {
    this.apiToken = process.env.TEMPEST_API_TOKEN;
    this.stationId = process.env.TEMPEST_STATION_ID;
    this.latitude = process.env.TEMPEST_LATITUDE;
    this.longitude = process.env.TEMPEST_LONGITUDE;
    this.baseUrl = 'https://swd.weatherflow.com/swd/rest';

    if (!this.apiToken || !this.stationId) {
      throw new Error('TEMPEST_API_TOKEN and TEMPEST_STATION_ID must be set in environment');
    }
  }

  /**
   * Get current weather observations
   */
  async getCurrentWeather() {
    const cacheKey = 'current_weather';
    const cached = cache.get(cacheKey);

    if (cached) {
      console.log('Returning cached current weather');
      return cached;
    }

    try {
      // Use forecast API which includes current_conditions
      const url = `${this.baseUrl}/better_forecast?station_id=${this.stationId}&token=${this.apiToken}`;
      const response = await axios.get(url);

      if (!response.data.current_conditions) {
        throw new Error('No current conditions available');
      }

      const data = this.formatCurrentWeatherFromForecast(response.data.current_conditions);
      cache.set(cacheKey, data, CACHE_TTL_CURRENT);

      return data;
    } catch (error) {
      console.error('Error fetching current weather:', error.message);
      throw error;
    }
  }

  /**
   * Get forecast data
   */
  async getForecast() {
    const cacheKey = 'forecast';
    const cached = cache.get(cacheKey);

    if (cached) {
      console.log('Returning cached forecast');
      return cached;
    }

    try {
      const url = `${this.baseUrl}/better_forecast?station_id=${this.stationId}&token=${this.apiToken}`;
      const response = await axios.get(url);

      const data = this.formatForecast(response.data);
      cache.set(cacheKey, data, CACHE_TTL_FORECAST);

      return data;
    } catch (error) {
      console.error('Error fetching forecast:', error.message);
      throw error;
    }
  }

  /**
   * Get both current weather and forecast in one call
   */
  async getCompleteWeather() {
    const [current, forecast] = await Promise.all([
      this.getCurrentWeather(),
      this.getForecast()
    ]);

    return {
      current,
      forecast,
      station: {
        id: this.stationId,
        latitude: this.latitude,
        longitude: this.longitude
      }
    };
  }

  /**
   * Format current weather data from forecast API current_conditions
   */
  formatCurrentWeatherFromForecast(conditions) {
    return {
      timestamp: conditions.time,
      temperature: {
        celsius: conditions.air_temperature,
        fahrenheit: (conditions.air_temperature * 9/5) + 32
      },
      feelsLike: {
        celsius: conditions.feels_like,
        fahrenheit: (conditions.feels_like * 9/5) + 32
      },
      humidity: conditions.relative_humidity,
      wind: {
        speed: conditions.wind_avg,
        gust: conditions.wind_gust,
        direction: conditions.wind_direction,
        directionText: conditions.wind_direction_cardinal || this.getWindDirection(conditions.wind_direction)
      },
      pressure: {
        mb: conditions.sea_level_pressure,
        inHg: conditions.sea_level_pressure * 0.02953
      },
      uv: conditions.uv,
      solarRadiation: conditions.solar_radiation,
      precipitation: {
        today: 0, // Not available in current_conditions
        lastHour: 0 // Not available in current_conditions
      },
      lightning: {
        strikeCount: 0,
        lastDistance: 0,
        lastTime: 0
      },
      conditions: conditions.conditions,
      icon: conditions.icon
    };
  }

  /**
   * Format current weather data (legacy - kept for compatibility)
   */
  formatCurrentWeather(data) {
    const obs = data.obs[0];

    return {
      timestamp: obs.timestamp,
      temperature: {
        celsius: obs.air_temperature,
        fahrenheit: (obs.air_temperature * 9/5) + 32
      },
      feelsLike: {
        celsius: obs.feels_like,
        fahrenheit: (obs.feels_like * 9/5) + 32
      },
      humidity: obs.relative_humidity,
      wind: {
        speed: obs.wind_avg,
        gust: obs.wind_gust,
        direction: obs.wind_direction,
        directionText: this.getWindDirection(obs.wind_direction)
      },
      pressure: {
        mb: obs.sea_level_pressure,
        inHg: obs.sea_level_pressure * 0.02953
      },
      uv: obs.uv,
      solarRadiation: obs.solar_radiation,
      precipitation: {
        today: obs.precip_accum_local_day,
        lastHour: obs.precip_accum_last_1hr
      },
      lightning: {
        strikeCount: obs.lightning_strike_count,
        lastDistance: obs.lightning_strike_last_distance,
        lastTime: obs.lightning_strike_last_epoch
      }
    };
  }

  /**
   * Format forecast data
   */
  formatForecast(data) {
    const result = {
      current: data.current_conditions,
      hourly: [],
      daily: []
    };

    // Format hourly forecast (next 24 hours)
    if (data.forecast && data.forecast.hourly) {
      result.hourly = data.forecast.hourly.slice(0, 24).map(hour => ({
        time: hour.time,
        temperature: {
          celsius: hour.air_temperature,
          fahrenheit: (hour.air_temperature * 9/5) + 32
        },
        conditions: hour.conditions,
        icon: hour.icon,
        precipProbability: hour.precip_probability,
        humidity: hour.relative_humidity,
        wind: {
          speed: hour.wind_avg,
          direction: hour.wind_direction
        }
      }));
    }

    // Format daily forecast
    if (data.forecast && data.forecast.daily) {
      result.daily = data.forecast.daily.map(day => ({
        date: day.day_start_local,
        conditions: day.conditions,
        icon: day.icon,
        temperature: {
          high: {
            celsius: day.air_temp_high,
            fahrenheit: (day.air_temp_high * 9/5) + 32
          },
          low: {
            celsius: day.air_temp_low,
            fahrenheit: (day.air_temp_low * 9/5) + 32
          }
        },
        precipProbability: day.precip_probability,
        precipType: day.precip_type,
        sunrise: day.sunrise,
        sunset: day.sunset
      }));
    }

    return result;
  }

  /**
   * Convert wind direction degrees to cardinal direction
   */
  getWindDirection(degrees) {
    const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
                       'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    const index = Math.round(degrees / 22.5) % 16;
    return directions[index];
  }

  /**
   * Clear cache (useful for testing)
   */
  clearCache() {
    cache.flushAll();
  }
}

module.exports = new TempestAPI();
