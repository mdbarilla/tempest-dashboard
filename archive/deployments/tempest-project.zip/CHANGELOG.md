# Changelog

All notable changes to the Tempest Weather Suite will be documented in this file.

## [Unreleased]

### Added
- Initial project structure for weather suite
- Node.js Express backend API server
- SQLite database for historical weather data storage
- Tempest API integration service with caching
- RESTful API endpoints for weather data
- Google Home webhook integration via Dialogflow
- Minimalist React dashboard for Raspberry Pi display
  - Real-time weather display with auto-refresh
  - Current conditions with large temperature display
  - Weather metrics cards (humidity, wind, pressure, UV)
  - 5-day forecast display
  - Calm muted color palette optimized for always-on display
  - Kiosk mode with auto-hiding cursor
  - Responsive design for various screen sizes
- Comprehensive documentation
  - Raspberry Pi 4 setup guide with kiosk mode configuration
  - Google Home integration guide with Dialogflow setup
  - Quick start guide for local development
- Project configuration files
  - Environment variable templates
  - Package.json for backend and frontend
  - Git ignore rules

### Architecture
- Backend: Node.js with Express
- Frontend: React 18
- Database: SQLite for time-series weather data
- API: RESTful endpoints with caching
- Voice: Google Dialogflow webhook integration
- Deployment: PM2 process manager for Raspberry Pi

### To Be Implemented
- Analytics dashboard with Chart.js for data visualization
- Historical weather data charts and trends
- Data export functionality
- Advanced weather alerts
- Multi-station support
- Mobile app version
- Docker containerization
- Automated testing suite

## [0.1.0] - 2024-01-16

### Initial Setup
- Project structure created
- Development environment configured
- Legacy HTML dashboard moved to apps/legacy/
- Foundation laid for multi-app weather suite

---

## Version History

- **Unreleased** - Current development version
- **0.1.0** - Initial project structure and planning
