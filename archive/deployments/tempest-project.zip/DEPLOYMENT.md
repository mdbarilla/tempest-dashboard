# Tempest Weather Dashboard - Production Deployment Guide

This guide will help you deploy the Tempest Weather Dashboard to a Raspberry Pi for production use.

## Prerequisites

- Raspberry Pi 4 (2GB+ RAM recommended)
- MicroSD card (16GB+ recommended)
- Your Tempest API token and station ID
- Network connectivity for the Pi

## Part 1: Prepare Your Mac for Deployment

### 1.1 Build the Production Dashboard

```bash
cd apps/dashboard
npm run build
```

This creates an optimized production build in `apps/dashboard/build/`.

### 1.2 Create Deployment Package

From the project root:

```bash
# Create deployment directory
mkdir -p deployment
cd deployment

# Copy backend files
cp -r ../backend .
cd backend
npm install --production
cd ..

# Copy built dashboard
cp -r ../apps/dashboard/build ./dashboard

# Create necessary directories
mkdir -p data logs
```

## Part 2: Set Up Raspberry Pi

### 2.1 Install Raspberry Pi OS

1. Download [Raspberry Pi Imager](https://www.raspberrypi.com/software/)
2. Flash Raspberry Pi OS Lite (64-bit) to your SD card
3. Enable SSH in the imager settings
4. Set hostname: `tempest-weather`
5. Configure WiFi credentials if needed
6. Insert SD card and boot the Pi

### 2.2 Initial Pi Configuration

SSH into your Pi:

```bash
ssh pi@tempest-weather.local
# Default password: raspberry (change this!)
```

Update the system:

```bash
sudo apt update && sudo apt upgrade -y
```

### 2.3 Install Node.js

```bash
# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version
npm --version
```

### 2.4 Install nginx

```bash
sudo apt install -y nginx
```

### 2.5 Install PM2 (Process Manager)

```bash
sudo npm install -g pm2
```

## Part 3: Deploy Application

### 3.1 Transfer Files to Pi

From your Mac, in the project root:

```bash
# Create deployment archive
tar -czf tempest-deploy.tar.gz deployment/

# Copy to Pi
scp tempest-deploy.tar.gz pi@tempest-weather.local:~/

# SSH into Pi
ssh pi@tempest-weather.local

# Extract files
tar -xzf tempest-deploy.tar.gz
cd deployment
```

### 3.2 Configure Environment

On the Pi:

```bash
cd ~/deployment/backend

# Create .env file
nano .env
```

Add your configuration:

```
PORT=3001
TEMPEST_API_TOKEN=your_token_here
TEMPEST_STATION_ID=204768
NODE_ENV=production
```

Save with `Ctrl+X`, then `Y`, then `Enter`.

### 3.3 Configure nginx

```bash
sudo nano /etc/nginx/sites-available/tempest
```

Paste this configuration:

```nginx
server {
    listen 80 default_server;
    listen [::]:80 default_server;

    server_name _;
    root /home/pi/deployment/dashboard;
    index index.html;

    # Serve static files
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy API requests
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/tempest /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl restart nginx
```

### 3.4 Start the Backend with PM2

```bash
cd ~/deployment/backend
pm2 start server.js --name tempest-backend
pm2 save
pm2 startup
# Follow the instructions printed by the command above
```

### 3.5 Verify Deployment

Visit `http://tempest-weather.local` in your browser. You should see your dashboard!

## Part 4: Set Up Kiosk Mode (Optional)

To run the Pi as a dedicated weather display:

### 4.1 Install Desktop Environment

```bash
sudo apt install -y --no-install-recommends xserver-xorg x11-xserver-utils xinit openbox chromium-browser
```

### 4.2 Configure Auto-login

```bash
sudo raspi-config
# Navigate to: System Options > Boot / Auto Login > Console Autologin
```

### 4.3 Create Kiosk Script

```bash
mkdir -p ~/.config/openbox
nano ~/.config/openbox/autostart
```

Add:

```bash
# Disable screensaver
xset s off
xset s noblank
xset -dpms

# Hide cursor after inactivity
unclutter -idle 0.1 &

# Start Chromium in kiosk mode
chromium-browser --noerrdialogs --disable-infobars --kiosk --disable-features=TranslateUI http://localhost &
```

### 4.4 Configure startx on boot

```bash
nano ~/.bash_profile
```

Add:

```bash
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
  startx
fi
```

Reboot:

```bash
sudo reboot
```

## Maintenance

### Update the Dashboard

From your Mac:

```bash
cd apps/dashboard
npm run build

# Create archive
cd ../..
tar -czf dashboard-update.tar.gz apps/dashboard/build/

# Copy to Pi
scp dashboard-update.tar.gz pi@tempest-weather.local:~/

# On Pi
ssh pi@tempest-weather.local
tar -xzf dashboard-update.tar.gz
rm -rf deployment/dashboard/*
mv apps/dashboard/build/* deployment/dashboard/
sudo systemctl reload nginx
```

### View Backend Logs

```bash
pm2 logs tempest-backend
```

### Restart Backend

```bash
pm2 restart tempest-backend
```

## Troubleshooting

### Dashboard won't load
```bash
sudo systemctl status nginx
sudo journalctl -u nginx -n 50
```

### Backend issues
```bash
pm2 logs tempest-backend
pm2 restart tempest-backend
```

### Check disk space
```bash
df -h
```

### Clear PM2 logs
```bash
pm2 flush
```

## Performance Tips

1. **Reduce Memory Usage**: Use Raspberry Pi OS Lite
2. **Enable Swap**: Increase swap file size if needed
3. **Monitor Resources**: `htop` to watch CPU/RAM
4. **Optimize Database**: Run `VACUUM` on SQLite periodically

## Security Notes

- Change default Pi password immediately
- Keep system updated: `sudo apt update && sudo apt upgrade`
- Consider setting up UFW firewall
- Use SSH keys instead of passwords
- Keep your Tempest API token secure
