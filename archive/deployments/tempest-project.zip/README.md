# Tempest Weather Suite

A comprehensive suite of weather applications utilizing the Tempest Weather API, optimized for Raspberry Pi 4 and Google Home integration.

## Overview

This project consists of multiple interconnected applications:

1. **Backend API Server** - Centralized Node.js server for data fetching, caching, and storage
2. **Minimalist Dashboard** - Clean, always-on display optimized for Raspberry Pi
3. **Analytics Dashboard** - Interactive data visualization and historical analysis
4. **Google Home Integration** - Voice-activated weather reports
5. **Legacy Dashboard** - Original HTML-based weather display

## Architecture

```
Tempest/
├── backend/                    # Node.js Express API server
│   ├── api/                   # REST API endpoints
│   ├── services/              # Tempest API integration & data processing
│   ├── webhooks/              # Google Home Dialogflow webhook
│   └── config/                # Configuration files
├── apps/
│   ├── dashboard/             # React minimalist Pi display
│   ├── analytics/             # React analytics with Chart.js
│   └── legacy/                # Original HTML dashboard
├── shared/                    # Shared utilities, styles, icons
├── raspberry-pi/              # Pi-specific setup scripts
└── docs/                      # Documentation

```

## Technology Stack

- **Backend**: Node.js with Express
- **Frontend**: React with Chart.js
- **Database**: SQLite (time-series weather data)
- **Voice Integration**: Google Dialogflow + Webhooks
- **Deployment**: Raspberry Pi 4 (kiosk mode)

## Quick Start

### Prerequisites

- Node.js 18+ and npm
- Tempest Weather API token ([Get one here](https://tempestwx.com))
- Your Tempest station ID

### Installation

1. Clone and navigate to project:
```bash
cd Tempest
```

2. Install backend dependencies:
```bash
cd backend
npm install
```

3. Configure environment:
```bash
cp .env.example .env
# Edit .env with your Tempest API credentials
```

4. Start the backend server:
```bash
npm run dev
```

5. Install and run dashboard app:
```bash
cd ../apps/dashboard
npm install
npm start
```

## Configuration

Copy `backend/.env.example` to `backend/.env` and configure:

```env
TEMPEST_API_TOKEN=your_token_here
TEMPEST_STATION_ID=your_station_id
PORT=3001
DATABASE_PATH=./data/weather.db
```

## Applications

### 1. Minimalist Dashboard
- Clean, high-contrast design
- Calm muted color palette
- Specialized weather icons
- Subtle animations
- Optimized for always-on display

**Access**: `http://localhost:3000`

### 2. Analytics Dashboard
- Historical weather trends
- Interactive charts and graphs
- Data export functionality
- Multiple visualization modes

**Access**: `http://localhost:3000/analytics`

### 3. Backend API
- RESTful weather data endpoints
- Automatic data caching
- Historical data storage
- Google Home webhook handler

**Access**: `http://localhost:3001/api`

## Google Home Integration

See [docs/google-home-setup.md](docs/google-home-setup.md) for complete instructions.

**Quick test**:
"Hey Google, ask Tempest what's the weather"

## Raspberry Pi Deployment

See [docs/raspberry-pi-setup.md](docs/raspberry-pi-setup.md) for complete setup guide.

**Features**:
- Auto-start on boot
- Kiosk mode (fullscreen, no screensaver)
- Chromium optimized for display
- Automatic crash recovery

## API Endpoints

### Weather Data
- `GET /api/current` - Current weather observations
- `GET /api/forecast` - Forecast data
- `GET /api/historical?start=YYYY-MM-DD&end=YYYY-MM-DD` - Historical data

### Google Home
- `POST /webhooks/google-home` - Dialogflow fulfillment webhook

## Development

### Backend Development
```bash
cd backend
npm run dev  # Starts with nodemon for hot-reload
```

### Dashboard Development
```bash
cd apps/dashboard
npm start  # Starts React dev server
```

### Analytics Development
```bash
cd apps/analytics
npm start
```

## Project Status

- [x] Project structure created
- [ ] Backend API server
- [ ] SQLite database integration
- [ ] Google Home webhook
- [ ] Minimalist dashboard UI
- [ ] Analytics dashboard
- [ ] Raspberry Pi configuration
- [ ] Deployment automation

## License

MIT

## Credits

Weather data provided by [Tempest Weather](https://tempestwx.com)
