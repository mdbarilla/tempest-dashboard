import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CurrentWeather from './components/CurrentWeather';
import Forecast from './components/Forecast';
import Metrics from './components/Metrics';
import './styles/App.css';

const API_BASE_URL = process.env.REACT_APP_API_URL || '/api/weather';
const REFRESH_INTERVAL = 60000; // 60 seconds

function App() {
  const [weatherData, setWeatherData] = useState(null);
  const [recentData, setRecentData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);

  useEffect(() => {
    fetchWeather();
    const interval = setInterval(fetchWeather, REFRESH_INTERVAL);

    // Auto light/dark theme based on time of day
    const updateTheme = () => {
      const hour = new Date().getHours();
      // Dark mode from 8 PM (20:00) to 6 AM (6:00)
      if (hour >= 20 || hour < 6) {
        document.body.classList.add('theme-dark');
      } else {
        document.body.classList.remove('theme-dark');
      }
    };

    updateTheme();
    const themeInterval = setInterval(updateTheme, 60000); // Check every minute

    // Hide cursor after 5 seconds of no movement (kiosk mode)
    let timeout;
    const handleMouseMove = () => {
      document.body.classList.remove('hide-cursor');
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        document.body.classList.add('hide-cursor');
      }, 5000);
    };

    document.addEventListener('mousemove', handleMouseMove);

    return () => {
      clearInterval(interval);
      clearInterval(themeInterval);
      clearTimeout(timeout);
      document.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const fetchWeather = async () => {
    try {
      const [weatherResponse, recentResponse] = await Promise.all([
        axios.get(`${API_BASE_URL}/complete`),
        axios.get(`${API_BASE_URL}/recent`).catch(() => ({ data: { success: false } }))
      ]);

      if (weatherResponse.data.success) {
        setWeatherData(weatherResponse.data.data);
        setLastUpdate(new Date());
        setError(null);
      }

      if (recentResponse.data.success) {
        setRecentData(recentResponse.data.data);
      }
    } catch (err) {
      console.error('Error fetching weather:', err);
      setError('Unable to fetch weather data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="app loading">
        <div className="loading-spinner"></div>
        <p>Loading weather data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="app error">
        <div className="error-icon">⚠️</div>
        <h2>{error}</h2>
        <p>Check your backend server is running</p>
        <button onClick={fetchWeather}>Retry</button>
      </div>
    );
  }

  return (
    <div className="app">
      <div className="container">
        <main className="main-content">
          <CurrentWeather
            current={weatherData.current}
            forecast={weatherData.forecast}
            lastUpdate={lastUpdate}
          />

          <Metrics current={weatherData.current} forecast={weatherData.forecast} recent={recentData} />

          <Forecast forecast={weatherData.forecast} />
        </main>

        <footer className="footer">
          <a
            href="https://tempestwx.com/station/204768/"
            target="_blank"
            rel="noopener noreferrer"
            className="footer-link"
          >
            <span>Tempest Station #204768 • Wayland, MA</span>
            <svg viewBox="0 0 24 24">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <polyline points="15 3 21 3 21 9" />
              <line x1="10" y1="14" x2="21" y2="3" />
            </svg>
          </a>
        </footer>
      </div>
    </div>
  );
}

export default App;
