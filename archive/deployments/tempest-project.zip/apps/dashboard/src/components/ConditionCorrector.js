import React, { useState } from 'react';
import './ConditionCorrector.css';

const COMMON_CONDITIONS = [
  'Clear',
  'Partly Cloudy',
  'Mostly Cloudy',
  'Cloudy',
  'Rain',
  'Snow',
  'Freezing Rain',
  'Sleet',
  'Drizzle',
  'Fog',
  'Thunderstorm'
];

const ConditionCorrector = ({ currentCondition, temperature, timestamp, onCorrect, isCorrected }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCondition, setSelectedCondition] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selectedCondition) return;

    setIsSubmitting(true);
    try {
      await onCorrect(selectedCondition);
      setIsOpen(false);
      setSelectedCondition('');
    } catch (error) {
      console.error('Error submitting correction:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) {
    return (
      <button
        className={`condition-report-btn ${isCorrected ? 'corrected' : ''}`}
        onClick={() => setIsOpen(true)}
        title={isCorrected ? "Condition corrected - click to update again" : "Report different conditions"}
      >
        {isCorrected ? 'Corrected' : 'Report Different'}
      </button>
    );
  }

  return (
    <div className="condition-corrector">
      <div className="corrector-header">
        <span>Current: {currentCondition}</span>
        <button className="close-btn" onClick={() => setIsOpen(false)}>×</button>
      </div>

      <div className="corrector-body">
        <label>Select actual condition:</label>
        <div className="condition-options">
          {COMMON_CONDITIONS.map(condition => (
            <button
              key={condition}
              className={`condition-option ${selectedCondition === condition ? 'selected' : ''}`}
              onClick={() => setSelectedCondition(condition)}
              disabled={isSubmitting}
            >
              {condition}
            </button>
          ))}
        </div>

        <div className="corrector-actions">
          <button
            className="submit-btn"
            onClick={handleSubmit}
            disabled={!selectedCondition || isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit'}
          </button>
          <button
            className="cancel-btn"
            onClick={() => setIsOpen(false)}
            disabled={isSubmitting}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConditionCorrector;
