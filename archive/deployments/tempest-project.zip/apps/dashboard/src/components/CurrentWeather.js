import React, { useState } from 'react';
import axios from 'axios';
import WeatherIcon from './WeatherIcon';
import ConditionCorrector from './ConditionCorrector';
import './CurrentWeather.css';

const API_BASE_URL = process.env.REACT_APP_API_URL || '/api/weather';

const CurrentWeather = ({ current, forecast, lastUpdate }) => {
  const [isCorrected, setIsCorrected] = useState(forecast?.current?.corrected || false);

  if (!current) return null;

  const temp = Math.round(current.temperature.fahrenheit);
  const feelsLike = Math.round(current.feelsLike.fahrenheit);
  const conditions = forecast?.current?.conditions || 'Clear';
  const originalCondition = forecast?.current?.originalCondition;

  const handleCorrection = async (reportedCondition) => {
    try {
      await axios.post(`${API_BASE_URL}/correction`, {
        timestamp: current.timestamp,
        reportedCondition,
        originalCondition: originalCondition || conditions,
        temperature: current.temperature.fahrenheit
      });

      setIsCorrected(true);

      // Refresh the page to get updated conditions
      window.location.reload();
    } catch (error) {
      console.error('Error submitting correction:', error);
      throw error;
    }
  };

  return (
    <div className="current-weather">
      <div className="weather-header">
        <div className="location-info">
          <h1>Tower Hill</h1>
          {lastUpdate && (
            <div className="last-update">
              Updated {lastUpdate.toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
              })}
            </div>
          )}
        </div>
        <WeatherIcon condition={conditions} size={64} className="weather-icon" />
      </div>

      <div className="temperature-display">
        <div className="temperature">{temp}°</div>
        <div className="conditions-container">
          <div className="conditions">{conditions}</div>
          <ConditionCorrector
            currentCondition={conditions}
            temperature={current.temperature.fahrenheit}
            timestamp={current.timestamp}
            onCorrect={handleCorrection}
            isCorrected={isCorrected}
          />
        </div>
        {Math.abs(temp - feelsLike) > 3 && (
          <div className="feels-like">Feels like {feelsLike}°</div>
        )}
        {forecast?.daily?.[0] && (
          <div className="high-low">
            <span className="temp-high-display">{Math.round(forecast.daily[0].temperature.high.fahrenheit)}°</span>
            <span className="temp-separator"> / </span>
            <span className="temp-low-display">{Math.round(forecast.daily[0].temperature.low.fahrenheit)}°</span>
          </div>
        )}
      </div>

      {/* Hourly preview - scrollable, showing next 24 hours */}
      {forecast?.hourly && (
        <div className="hourly-preview-container">
          <div className="hourly-preview">
            {forecast.hourly.slice(0, 24).map((hour, index) => {
              const time = new Date(hour.time * 1000);
              const hourTemp = Math.round(hour.temperature.fahrenheit);
              const hourCondition = hour.conditions || conditions;

              return (
                <div key={index} className="hourly-item">
                  <div className="hourly-time">
                    {time.toLocaleTimeString('en-US', { hour: 'numeric', hour12: true }).replace(' ', '')}
                  </div>
                  <div className="hourly-icon-small" data-condition={hourCondition}>
                    <WeatherIcon condition={hourCondition} size={28} />
                  </div>
                  <div className="hourly-temp">{hourTemp}°</div>
                  {hour.precipProbability > 20 && (
                    <div className="hourly-precip">{hour.precipProbability}%</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default CurrentWeather;
