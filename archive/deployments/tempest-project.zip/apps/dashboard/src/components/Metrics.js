import React from 'react';
import MetricIcon from './MetricIcon';
import Sparkline from './Sparkline';
import './Metrics.css';

const Metrics = ({ current, forecast, recent, onMetricClick }) => {
  if (!current) return null;

  // Get trend data - prefer recent observations over forecast
  const getTrendData = (metric) => {
    // Use recent historical data if available (from database) and has enough data points
    if (recent?.[metric] && Array.isArray(recent[metric])) {
      const validData = recent[metric].filter(v => v !== null && v !== undefined);
      if (validData.length >= 2) {
        return recent[metric];
      }
    }

    // Fallback to forecast data for metrics that support it
    if (!forecast?.hourly || !Array.isArray(forecast.hourly) || forecast.hourly.length < 6) {
      return null;
    }

    const last6Hours = forecast.hourly.slice(0, 6);

    switch (metric) {
      case 'pressure':
        return null; // No pressure in forecast
      case 'humidity':
        return last6Hours.map(h => h.humidity || null).reverse();
      case 'wind':
        return last6Hours.map(h => h.wind?.speed || null).reverse();
      case 'precipitation':
        return last6Hours.map(h => h.precipProbability || 0).reverse();
      default:
        return null;
    }
  };

  // Calculate pressure trend
  const getPressureTrend = () => {
    const pressureData = recent?.pressure;
    if (!pressureData || !Array.isArray(pressureData) || pressureData.length < 2) {
      return 'stable';
    }

    const validData = pressureData.filter(v => v !== null && v !== undefined);
    if (validData.length < 2) return 'stable';

    const latestPressure = validData[validData.length - 1];
    const earlierPressure = validData[0];
    const diff = latestPressure - earlierPressure;

    // Threshold: 0.5 mb change is considered significant
    if (diff > 0.5) return 'rising';
    if (diff < -0.5) return 'falling';
    return 'stable';
  };

  // Get sunset or sunrise time based on current time
  const getSunTime = () => {
    if (!forecast?.daily?.[0]) return null;

    const now = new Date();
    const sunrise = forecast.daily[0].sunrise ? new Date(forecast.daily[0].sunrise * 1000) : null;
    const sunset = forecast.daily[0].sunset ? new Date(forecast.daily[0].sunset * 1000) : null;

    if (!sunrise || !sunset) return null;

    // If current time is before sunset, show sunset, otherwise show next sunrise
    if (now < sunset) {
      return {
        label: 'Sunset',
        time: sunset.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })
      };
    } else {
      // Show tomorrow's sunrise if available
      const tomorrowSunrise = forecast.daily[1]?.sunrise ? new Date(forecast.daily[1].sunrise * 1000) : sunrise;
      return {
        label: 'Sunrise',
        time: tomorrowSunrise.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })
      };
    }
  };

  const handleClick = (link) => {
    if (onMetricClick) {
      onMetricClick(link);
    } else {
      console.log('Navigate to:', link);
    }
  };

  const pressureTrend = getPressureTrend();
  const sunTime = getSunTime();

  const metrics = [
    {
      type: 'pressure',
      label: 'Pressure',
      value: current.pressure.inHg.toFixed(2),
      unit: 'inHg',
      secondary: `${current.pressure.mb.toFixed(1)} mb · ${pressureTrend}`,
      link: '/analytics/pressure'
    },
    {
      type: 'humidity',
      label: 'Humidity',
      value: Math.round(current.humidity),
      unit: '%',
      link: '/analytics/humidity'
    },
    {
      type: 'wind',
      label: 'Wind',
      value: Math.round(current.wind.speed),
      unit: 'mph',
      secondary: `Gusts ${Math.round(current.wind.gust)} mph ${current.wind.directionText}`,
      link: '/analytics/wind'
    },
    {
      type: 'precipitation',
      label: 'Precipitation',
      value: current.precipitation.today.toFixed(2),
      unit: 'in',
      secondary: `${current.precipitation.lastHour.toFixed(2)} in last hour`,
      link: '/analytics/precipitation'
    },
    {
      type: 'solar',
      label: 'Solar Radiation',
      value: Math.round(current.solarRadiation || 0),
      unit: 'W/m²',
      secondary: `UV Index ${current.uv || 0}`,
      link: '/analytics/solar'
    },
    ...(sunTime ? [{
      type: sunTime.label.toLowerCase(),
      label: sunTime.label,
      value: sunTime.time.split(' ')[0],
      unit: sunTime.time.split(' ')[1],
      link: '/analytics/sun'
    }] : [])
  ];

  return (
    <div className="metrics-section">
      <div className="metrics">
        {metrics.map((metric, index) => (
          <div
            key={index}
            className="metric-card"
            onClick={() => handleClick(metric.link)}
            style={{
              animationDelay: `${0.3 + index * 0.05}s`
            }}
          >
            <MetricIcon type={metric.type} size={32} className="metric-icon" />
            <div className="metric-content">
              <div className="metric-label">{metric.label}</div>
              <div className="metric-value">
                {metric.value}
                {metric.unit && <span className="metric-unit">{metric.unit}</span>}
              </div>
              {metric.secondary && (
                <div className="metric-secondary">{metric.secondary}</div>
              )}
              {getTrendData(metric.type) && (
                <div className="metric-trend">
                  <Sparkline
                    data={getTrendData(metric.type)}
                    width={120}
                    height={24}
                    color="var(--text-secondary)"
                  />
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Metrics;
