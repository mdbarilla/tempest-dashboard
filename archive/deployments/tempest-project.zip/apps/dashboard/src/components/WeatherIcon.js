import React from 'react';

const WeatherIcon = ({ condition, size = 48, className = '' }) => {
  const getIconProps = (customViewBox) => ({
    width: size,
    height: size,
    viewBox: customViewBox || "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className: className
  });

  const iconProps = getIconProps();

  const titleProps = {
    role: "img",
    "aria-label": condition
  };

  // Determine icon based on condition
  const getIcon = () => {
    const lowerCondition = condition?.toLowerCase() || '';

    // Clear/Sunny
    if (lowerCondition.includes('clear') && !lowerCondition.includes('night')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <circle cx="12" cy="12" r="4" />
          <line x1="12" y1="1" x2="12" y2="3" />
          <line x1="12" y1="21" x2="12" y2="23" />
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
          <line x1="1" y1="12" x2="3" y2="12" />
          <line x1="21" y1="12" x2="23" y2="12" />
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
        </svg>
      );
    }

    // Clear Night/Moon
    if (lowerCondition.includes('clear') || lowerCondition.includes('night')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
        </svg>
      );
    }

    // Partly Cloudy Day
    if (lowerCondition.includes('partly') && !lowerCondition.includes('night')) {
      const partlyCloudyProps = getIconProps("0 0 500 500");
      return (
        <svg {...partlyCloudyProps} fill="currentColor" stroke="currentColor" strokeWidth="8" strokeLinejoin="round" strokeLinecap="round" {...titleProps}>
          <title>{condition}</title>
          <g>
            <path d="M317.686,92.779c6.749,0,12.266-5.585,12.266-12.418V64.666c0-6.832-5.517-12.417-12.266-12.417
              s-12.265,5.585-12.265,12.417v15.695C305.421,87.194,310.937,92.779,317.686,92.779z"/>
            <path d="M429.14,105.751l-11.102,11.101c-4.822,4.83-4.878,12.681-0.097,17.456
              c4.768,4.774,12.611,4.726,17.448-0.104l11.102-11.101c4.822-4.83,4.878-12.681,0.11-17.456
              C441.82,100.873,433.977,100.921,429.14,105.751z"/>
            <path d="M487.583,222.298h-15.702c-6.819,0-12.418,5.516-12.418,12.265c0,6.75,5.585,12.265,12.418,12.265h15.688
              c6.833,0,12.418-5.516,12.432-12.265C500,227.814,494.415,222.298,487.583,222.298z"/>
            <path d="M199.964,134.196c4.83,4.83,12.688,4.879,17.469,0.104c4.768-4.774,4.726-12.626-0.104-17.456
              l-11.108-11.094c-4.83-4.83-12.688-4.878-17.462-0.104c-4.768,4.774-4.719,12.625,0.111,17.456L199.964,134.196z"/>
            <path d="M317.686,148.811c47.273,0,85.745,38.466,85.745,85.752c0,8.808-1.344,17.303-3.811,25.303
              c8.759,2.342,16.146,7.913,20.788,15.467c5.017-12.626,7.858-26.356,7.858-40.77c0-61.076-49.519-110.587-110.581-110.587
              c-34.619,0-65.48,15.917-85.756,40.814c9.05,0.998,16.991,5.377,22.632,11.933C270.246,159.614,292.698,148.811,317.686,148.811z"/>
            <path d="M338.35,254.152c-10.935,0-21.564,1.802-31.737,5.367c-20.816-50.201-70.747-84.196-125.877-84.196
              c-68.712,0-126.629,51.708-135.111,119.093C18.045,307.763,0,336.021,0,367.037c0,44.502,36.214,80.715,80.729,80.715H338.35
              c53.371,0,96.791-43.42,96.791-96.791S391.721,254.152,338.35,254.152z M338.35,422.917H80.729
              c-30.822,0-55.893-25.071-55.893-55.88c0-23.324,14.746-44.39,36.699-52.428l7.567-2.772l0.554-8.038
              c3.991-58.114,52.775-103.641,111.08-103.641c48.908,0,92.796,32.707,106.724,79.54l4.297,14.427l13.346-6.957
              c10.408-5.419,21.593-8.177,33.248-8.177c39.678,0,71.955,32.292,71.955,71.97C410.305,390.64,378.027,422.917,338.35,422.917z"/>
          </g>
        </svg>
      );
    }

    // Cloudy
    if (lowerCondition.includes('cloudy') || lowerCondition.includes('overcast')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
        </svg>
      );
    }

    // Rain
    if (lowerCondition.includes('rain') || lowerCondition.includes('drizzle')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <path d="M16 13v8m-8-8v8m4-8v8" />
          <path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25" />
        </svg>
      );
    }

    // Thunderstorm
    if (lowerCondition.includes('thunder') || lowerCondition.includes('storm')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <path d="M19 16.9A5 5 0 0 0 18 7h-1.26a8 8 0 1 0-11.62 9" />
          <polyline points="13 11 9 17 15 17 11 23" />
        </svg>
      );
    }

    // Snow
    if (lowerCondition.includes('snow') || lowerCondition.includes('sleet')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <path d="M20 17.58A5 5 0 0 0 18 8h-1.26A8 8 0 1 0 4 16.25" />
          <line x1="8" y1="16" x2="8.01" y2="16" />
          <line x1="8" y1="20" x2="8.01" y2="20" />
          <line x1="12" y1="18" x2="12.01" y2="18" />
          <line x1="12" y1="22" x2="12.01" y2="22" />
          <line x1="16" y1="16" x2="16.01" y2="16" />
          <line x1="16" y1="20" x2="16.01" y2="20" />
        </svg>
      );
    }

    // Fog/Mist
    if (lowerCondition.includes('fog') || lowerCondition.includes('mist') || lowerCondition.includes('haze')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <line x1="4" y1="6" x2="20" y2="6" />
          <line x1="4" y1="10" x2="20" y2="10" />
          <line x1="4" y1="14" x2="20" y2="14" />
          <line x1="4" y1="18" x2="14" y2="18" />
        </svg>
      );
    }

    // Wind
    if (lowerCondition.includes('wind')) {
      return (
        <svg {...iconProps} {...titleProps}>
          <title>{condition}</title>
          <path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2" />
        </svg>
      );
    }

    // Default: partly cloudy
    return (
      <svg {...iconProps} {...titleProps}>
        <title>{condition || 'Unknown'}</title>
        <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
      </svg>
    );
  };

  return getIcon();
};

export default WeatherIcon;
