# Quick Start Guide

Get your Tempest Weather Suite up and running in minutes.

## For Local Development (Mac/PC)

### 1. Get Your Tempest Credentials

1. Go to [tempestwx.com](https://tempestwx.com) and sign in
2. Navigate to **Settings** → **Data Authorizations** → **Create Token**
3. Copy your API token
4. Get your Station ID:
   - Visit: `https://swd.weatherflow.com/swd/rest/stations?token=YOUR_TOKEN`
   - Look for the `station_id` number

### 2. Setup Backend

```bash
cd backend

# Install dependencies
npm install

# Configure environment
cp .env.example .env

# Edit .env file with your credentials
nano .env  # or use any text editor
```

In `.env`, set:
```env
TEMPEST_API_TOKEN=your_token_here
TEMPEST_STATION_ID=your_station_id_here
TEMPEST_LATITUDE=42.3725
TEMPEST_LONGITUDE=-71.3161
```

Start the backend:
```bash
npm run dev
```

Backend will run on http://localhost:3001

Test it:
```bash
curl http://localhost:3001/api/weather/current
```

### 3. Setup Dashboard

Open a new terminal:

```bash
cd apps/dashboard

# Install dependencies
npm install

# Start development server
npm start
```

Dashboard will open automatically at http://localhost:3000

## For Raspberry Pi

See the complete [Raspberry Pi Setup Guide](./raspberry-pi-setup.md)

Quick version:

```bash
# On your Pi
cd ~/projects/tempest

# Setup backend
cd backend
npm install
cp .env.example .env
nano .env  # Add your credentials
npm start  # Test it works

# Setup dashboard
cd ../apps/dashboard
npm install
npm run build

# Install PM2 for auto-start
sudo npm install -g pm2 serve

# Start services
cd ~/projects/tempest/backend
pm2 start server.js --name tempest-backend

cd ~/projects/tempest/apps/dashboard
pm2 start "serve -s build -l 3000" --name tempest-dashboard

pm2 save
pm2 startup  # Follow the instructions
```

## For Google Home Integration

See the complete [Google Home Setup Guide](./google-home-setup.md)

Quick version:

1. Expose your backend with ngrok:
   ```bash
   ngrok http 3001
   ```

2. Create Dialogflow agent at [dialogflow.cloud.google.com](https://dialogflow.cloud.google.com/)

3. Configure webhook URL: `https://your-ngrok-url/webhooks/google-home`

4. Test: "Hey Google, ask Tempest what's the weather"

## Verify Everything Works

### Backend Health Check

```bash
curl http://localhost:3001/health
```

Expected response:
```json
{
  "status": "ok",
  "timestamp": "2024-01-16T...",
  "uptime": 123.45
}
```

### Get Current Weather

```bash
curl http://localhost:3001/api/weather/current
```

### Get Forecast

```bash
curl http://localhost:3001/api/weather/forecast
```

### Get Complete Weather Data

```bash
curl http://localhost:3001/api/weather/complete
```

## Troubleshooting

### Backend won't start

**Error: TEMPEST_API_TOKEN must be set**
- Make sure `.env` file exists in `backend/` directory
- Check that your API token is correctly set

**Error: EADDRINUSE (port already in use)**
- Another process is using port 3001
- Change PORT in `.env` or stop the other process

### Dashboard shows "Unable to fetch weather data"

1. Verify backend is running: `curl http://localhost:3001/health`
2. Check browser console for errors (F12)
3. Verify API token is valid at tempestwx.com

### No data showing

1. Check your Tempest station is online at tempestwx.com
2. Verify station ID is correct
3. Check backend logs for errors

## Next Steps

- Customize the dashboard appearance in `apps/dashboard/src/styles/`
- Add more weather metrics in `apps/dashboard/src/components/Metrics.js`
- Set up automatic backups of weather data
- Deploy to production with HTTPS
- Create the analytics app for historical data visualization

## Useful Commands

### Development

```bash
# Backend
cd backend
npm run dev          # Start with auto-reload

# Dashboard
cd apps/dashboard
npm start            # Start dev server
npm run build        # Build for production

# Both
npm install          # Install dependencies
```

### Production (Raspberry Pi)

```bash
pm2 status           # Check service status
pm2 logs             # View logs
pm2 restart all      # Restart all services
pm2 stop all         # Stop all services
pm2 start all        # Start all services
```

## Getting Help

If you run into issues:

1. Check the documentation in `docs/`
2. Review backend logs: `pm2 logs tempest-backend`
3. Check browser console for frontend errors
4. Verify your Tempest station is reporting data at tempestwx.com

## Development Tips

### Hot Reload

Both backend and frontend support hot reload in development mode:
- Backend: Uses nodemon (automatically reloads on file changes)
- Frontend: React dev server (automatically reloads on file changes)

### Environment Variables

Create `.env.local` in the dashboard for local overrides:

```env
REACT_APP_API_URL=http://192.168.1.100:3001/api/weather
```

### Testing Different Devices

Access dashboard from other devices on your network:
```
http://YOUR_IP:3000
```

Find your IP:
```bash
# Mac/Linux
ifconfig | grep inet

# Raspberry Pi
hostname -I
```

## Project Structure Reference

```
Tempest/
├── backend/              # Node.js API server
│   ├── api/             # REST endpoints
│   ├── services/        # Tempest API integration
│   ├── webhooks/        # Google Home webhook
│   └── server.js        # Main server file
├── apps/
│   ├── dashboard/       # React dashboard
│   └── legacy/          # Original HTML dashboard
├── docs/                # Documentation
│   ├── quick-start.md
│   ├── raspberry-pi-setup.md
│   └── google-home-setup.md
└── README.md            # Project overview
```
