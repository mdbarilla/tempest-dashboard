# Raspberry Pi 4 Setup Guide

Complete guide to set up your Tempest Weather Dashboard on Raspberry Pi 4 with kiosk mode for a dedicated display.

## Prerequisites

- Raspberry Pi 4 (2GB RAM minimum, 4GB recommended)
- MicroSD card (16GB or larger)
- Power supply (official Raspberry Pi USB-C power supply recommended)
- Monitor/Display with HDMI input
- Keyboard and mouse (for initial setup)
- Internet connection (WiFi or Ethernet)

## Step 1: Install Raspberry Pi OS

### Option A: Using Raspberry Pi Imager (Recommended)

1. Download [Raspberry Pi Imager](https://www.raspberrypi.com/software/)
2. Insert SD card into your computer
3. Open Raspberry Pi Imager
4. Choose OS: **Raspberry Pi OS (64-bit)** or **Raspberry Pi OS Lite** (for headless)
5. Choose Storage: Select your SD card
6. Click Settings (gear icon):
   - Set hostname: `tempest-weather`
   - Enable SSH
   - Set username and password
   - Configure WiFi (optional)
7. Click "Write" and wait for completion

### Option B: Manual Download

1. Download [Raspberry Pi OS](https://www.raspberrypi.com/software/operating-systems/)
2. Use Etcher or similar tool to flash the image to SD card

## Step 2: Initial Pi Setup

1. Insert SD card into Raspberry Pi
2. Connect monitor, keyboard, and mouse
3. Power on the Pi
4. Complete initial setup wizard:
   - Set country, language, timezone
   - Change password (if not set in imager)
   - Connect to WiFi
   - Update software (this may take a while)

5. Open Terminal and update system:

```bash
sudo apt update && sudo apt upgrade -y
```

## Step 3: Install Node.js

Install Node.js 18.x (LTS):

```bash
# Download and install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version
npm --version
```

## Step 4: Clone and Setup Project

```bash
# Create projects directory
mkdir -p ~/projects
cd ~/projects

# If using git, clone your repository
# git clone <your-repo-url> tempest
# OR copy your project files to ~/projects/tempest

cd tempest

# Install backend dependencies
cd backend
npm install

# Create and configure environment
cp .env.example .env
nano .env  # Edit with your API credentials

# Build the backend
npm start  # Test that it works, then Ctrl+C to stop

# Install dashboard dependencies
cd ../apps/dashboard
npm install

# Build the dashboard for production
npm run build
```

## Step 5: Install and Configure Web Server

We'll use a simple HTTP server to serve the built React app:

```bash
# Install serve globally
sudo npm install -g serve pm2

# Test serving the dashboard
cd ~/projects/tempest/apps/dashboard
serve -s build -l 3000
# Open browser to http://localhost:3000 to verify
# Press Ctrl+C to stop
```

## Step 6: Setup Auto-Start with PM2

PM2 will keep your backend and frontend running, and restart them if they crash:

```bash
# Start backend
cd ~/projects/tempest/backend
pm2 start server.js --name tempest-backend

# Start frontend server
cd ~/projects/tempest/apps/dashboard
pm2 start "serve -s build -l 3000" --name tempest-dashboard

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
# Copy and run the command that PM2 outputs

# Check status
pm2 status
```

## Step 7: Configure Chromium for Kiosk Mode

Create autostart script for kiosk mode:

```bash
# Create autostart directory
mkdir -p ~/.config/lxsession/LXDE-pi

# Create autostart file
nano ~/.config/lxsession/LXDE-pi/autostart
```

Add the following content:

```bash
@lxpanel --profile LXDE-pi
@pcmanfm --desktop --profile LXDE-pi
@xscreensaver -no-splash

# Disable screen blanking
@xset s off
@xset -dpms
@xset s noblank

# Hide mouse cursor after inactivity
@unclutter -idle 3 -root

# Start Chromium in kiosk mode
@chromium-browser --noerrdialogs --disable-infobars --kiosk http://localhost:3000 --incognito --disable-translate --no-first-run --fast --fast-start --disable-features=TranslateUI --disk-cache-dir=/dev/null
```

Save and exit (Ctrl+X, Y, Enter).

Install unclutter (hides cursor):

```bash
sudo apt install -y unclutter
```

## Step 8: Disable Screen Blanking

Edit the lightdm configuration:

```bash
sudo nano /etc/lightdm/lightdm.conf
```

Find the `[Seat:*]` section and add:

```ini
[Seat:*]
xserver-command=X -s 0 -dpms
```

## Step 9: Auto-Login (Optional)

For a true kiosk experience:

```bash
sudo raspi-config
```

Navigate to:
- **System Options** → **Boot / Auto Login** → **Desktop Autologin**

## Step 10: Test and Reboot

```bash
# Reboot to test everything
sudo reboot
```

After reboot, the dashboard should automatically:
1. Start the backend server
2. Start the frontend server
3. Open Chromium in fullscreen kiosk mode
4. Display your weather dashboard

## Troubleshooting

### Dashboard not loading

Check if services are running:

```bash
pm2 status
pm2 logs tempest-backend
pm2 logs tempest-dashboard
```

Restart services:

```bash
pm2 restart all
```

### Screen goes black

Check power settings:

```bash
xset q | grep timeout
```

Disable screensaver:

```bash
sudo apt remove xscreensaver
```

### Display resolution issues

Edit boot config:

```bash
sudo nano /boot/config.txt
```

Uncomment and adjust:

```ini
hdmi_group=2
hdmi_mode=82  # 1920x1080 @ 60Hz
```

### Chromium not starting in kiosk mode

Check autostart file:

```bash
cat ~/.config/lxsession/LXDE-pi/autostart
```

Test Chromium manually:

```bash
DISPLAY=:0 chromium-browser --kiosk http://localhost:3000
```

## Maintenance

### Update the dashboard

```bash
cd ~/projects/tempest
git pull  # If using git

cd apps/dashboard
npm install
npm run build

pm2 restart tempest-dashboard
```

### View logs

```bash
pm2 logs tempest-backend
pm2 logs tempest-dashboard
```

### Monitor system resources

```bash
pm2 monit
htop
```

## Performance Optimization

For Raspberry Pi 4, these settings help:

```bash
# Reduce GPU memory (more RAM for apps)
sudo nano /boot/config.txt

# Add or modify:
gpu_mem=128

# Disable Bluetooth if not needed
sudo systemctl disable bluetooth
sudo systemctl disable hciuart

# Disable WiFi if using Ethernet
sudo nano /boot/config.txt
# Add: dtoverlay=disable-wifi
```

## Network Configuration

### Static IP (Recommended for dedicated display)

```bash
sudo nano /etc/dhcpcd.conf
```

Add at the end:

```ini
interface eth0  # or wlan0 for WiFi
static ip_address=192.168.1.100/24
static routers=192.168.1.1
static domain_name_servers=8.8.8.8 8.8.4.4
```

## Remote Access

### SSH Access

```bash
# Enable SSH if not already enabled
sudo systemctl enable ssh
sudo systemctl start ssh

# Connect from another computer
ssh pi@tempest-weather.local
```

### VNC Access (Optional)

```bash
sudo raspi-config
# Interface Options → VNC → Enable

# Access via VNC Viewer from another computer
```

## Security Recommendations

1. Change default password
2. Keep system updated: `sudo apt update && sudo apt upgrade`
3. Configure firewall if exposed to internet
4. Use SSH keys instead of password authentication
5. Keep API tokens secure in `.env` file

## Helpful Commands

```bash
# Restart Pi
sudo reboot

# Shutdown Pi
sudo shutdown -h now

# Check temperature
vcgencmd measure_temp

# Check system info
neofetch

# Check disk space
df -h

# PM2 commands
pm2 status
pm2 restart all
pm2 stop all
pm2 logs
```

## Next Steps

- Set up automatic backups of your SD card
- Configure HTTPS if accessing remotely
- Set up Google Home integration (see [google-home-setup.md](./google-home-setup.md))
- Explore analytics dashboard for historical data analysis
