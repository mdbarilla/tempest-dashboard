const express = require('express');
const router = express.Router();
const tempestAPI = require('../services/tempest-api');
const db = require('../services/database');

/**
 * GET /api/weather/current
 * Get current weather conditions
 */
router.get('/current', async (req, res) => {
  try {
    const data = await tempestAPI.getCurrentWeather();

    // Store in database for historical tracking
    await db.saveObservation(data);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/forecast
 * Get forecast data
 */
router.get('/forecast', async (req, res) => {
  try {
    const data = await tempestAPI.getForecast();

    res.json({
      success: true,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/complete
 * Get both current conditions and forecast
 */
router.get('/complete', async (req, res) => {
  try {
    const data = await tempestAPI.getCompleteWeather();

    // Check for recent condition correction (30-minute window, synced across devices)
    if (data.current && data.current.timestamp) {
      const correction = await db.getRecentCorrection(data.current.timestamp, 30);

      if (correction) {
        // Apply the correction to the current forecast
        if (data.forecast && data.forecast.current) {
          data.forecast.current.conditions = correction.reported_condition;
          data.forecast.current.corrected = true;
          data.forecast.current.originalCondition = correction.original_condition;
          data.forecast.current.correctionTime = correction.created_at;
          data.forecast.current.correctionId = correction.id;
        }
      }

      // Get today's cumulative precipitation total and history
      const todayPrecip = await db.getTodayManualPrecipitation();
      const precipTotal = todayPrecip.reduce((sum, entry) => sum + entry.amount_inches, 0);

      if (todayPrecip.length > 0 && data.current.precipitation) {
        // Add cumulative precipitation data to current weather
        const latestEntry = todayPrecip[0]; // Most recent entry
        data.current.precipitation.manual = {
          amountInches: parseFloat(precipTotal.toFixed(2)),
          type: latestEntry.precip_type,
          notes: latestEntry.notes,
          temperature: latestEntry.temperature,
          timestamp: latestEntry.timestamp,
          id: latestEntry.id,
          entryCount: todayPrecip.length,
          isCumulative: true
        };
      }
    }

    res.json({
      success: true,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/historical
 * Get historical weather data from database
 * Query params: start (YYYY-MM-DD), end (YYYY-MM-DD), limit
 */
router.get('/historical', async (req, res) => {
  try {
    const { start, end, limit = 1000 } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        success: false,
        error: 'start and end dates are required (YYYY-MM-DD format)'
      });
    }

    const data = await db.getHistoricalData(start, end, parseInt(limit));

    res.json({
      success: true,
      count: data.length,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/stats
 * Get statistical summary for a date range
 */
router.get('/stats', async (req, res) => {
  try {
    const { start, end } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        success: false,
        error: 'start and end dates are required (YYYY-MM-DD format)'
      });
    }

    const stats = await db.getStatistics(start, end);

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/recent
 * Get recent observations for sparklines (last 6 hours)
 */
router.get('/recent', async (req, res) => {
  try {
    let { hours = 6 } = req.query;

    // Validate and sanitize hours parameter
    hours = parseInt(hours, 10);
    if (isNaN(hours) || hours < 0) {
      return res.status(400).json({
        success: false,
        error: 'Invalid hours parameter. Must be a positive number.'
      });
    }

    // Limit maximum hours to prevent performance issues
    hours = Math.min(hours, 168); // Max 7 days

    // Get data from the last N hours
    const now = new Date();
    const startTime = new Date(now - hours * 60 * 60 * 1000);
    const start = startTime.toISOString().split('T')[0];
    const end = now.toISOString().split('T')[0];

    const data = await db.getHistoricalData(start, end, 1000);

    // Filter to only last N hours
    const cutoffTime = Math.floor(startTime.getTime() / 1000);
    const recentData = data.filter(obs => obs.timestamp >= cutoffTime);

    // Sort by timestamp ascending (oldest first) for sparklines
    recentData.sort((a, b) => a.timestamp - b.timestamp);

    // Sample to approximately 6 data points evenly distributed
    const step = Math.max(1, Math.floor(recentData.length / 6));
    const sampled = recentData.filter((_, i) => i % step === 0).slice(-6);

    res.json({
      success: true,
      count: sampled.length,
      data: {
        pressure: sampled.map(d => d.pressure_mb),
        humidity: sampled.map(d => d.humidity),
        wind: sampled.map(d => d.wind_speed),
        precipitation: sampled.map(d => d.precip_today)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * POST /api/weather/correction
 * Submit a condition correction
 */
router.post('/correction', async (req, res) => {
  try {
    const { timestamp, reportedCondition, originalCondition, temperature } = req.body;

    if (!timestamp || !reportedCondition || !originalCondition) {
      return res.status(400).json({
        success: false,
        error: 'timestamp, reportedCondition, and originalCondition are required'
      });
    }

    const result = await db.saveConditionCorrection({
      timestamp,
      reportedCondition,
      originalCondition,
      temperature
    });

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/corrections
 * Get all condition corrections
 */
router.get('/corrections', async (req, res) => {
  try {
    const { limit = 100 } = req.query;
    const corrections = await db.getAllCorrections(parseInt(limit));

    res.json({
      success: true,
      count: corrections.length,
      data: corrections
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * DELETE /api/weather/correction/:id
 * Delete a condition correction (cancel/reset)
 */
router.delete('/correction/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({
        success: false,
        error: 'id is required'
      });
    }

    const result = await db.deleteConditionCorrection(parseInt(id));

    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Correction not found'
      });
    }

    res.json({
      success: true,
      message: 'Correction deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * POST /api/weather/precipitation/manual
 * Submit a manual precipitation entry
 */
router.post('/precipitation/manual', async (req, res) => {
  try {
    const { timestamp, amountInches, precipType, notes, temperature } = req.body;

    if (!timestamp || amountInches === undefined || !precipType) {
      return res.status(400).json({
        success: false,
        error: 'timestamp, amountInches, and precipType are required'
      });
    }

    // Validate precipitation type
    const validTypes = ['snow', 'rain', 'sleet', 'freezing rain', 'hail', 'mixed'];
    if (!validTypes.includes(precipType.toLowerCase())) {
      return res.status(400).json({
        success: false,
        error: `precipType must be one of: ${validTypes.join(', ')}`
      });
    }

    const result = await db.saveManualPrecipitation({
      timestamp,
      amountInches: parseFloat(amountInches),
      precipType: precipType.toLowerCase(),
      notes,
      temperature
    });

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/precipitation/manual
 * Get manual precipitation entries
 */
router.get('/precipitation/manual', async (req, res) => {
  try {
    const { start, end, limit = 100 } = req.query;

    let data;
    if (start && end) {
      data = await db.getManualPrecipitation(start, end, parseInt(limit));
    } else {
      data = await db.getAllManualPrecipitation(parseInt(limit));
    }

    res.json({
      success: true,
      count: data.length,
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * DELETE /api/weather/precipitation/manual/:id
 * Delete a manual precipitation entry
 */
router.delete('/precipitation/manual/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({
        success: false,
        error: 'id is required'
      });
    }

    const result = await db.deleteManualPrecipitation(parseInt(id));

    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Entry not found'
      });
    }

    res.json({
      success: true,
      message: 'Entry deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/weather/precipitation/today
 * Get today's precipitation entries with cumulative total
 */
router.get('/precipitation/today', async (req, res) => {
  try {
    const data = await db.getTodayManualPrecipitation();

    // Calculate cumulative total
    const total = data.reduce((sum, entry) => sum + entry.amount_inches, 0);

    res.json({
      success: true,
      count: data.length,
      total: parseFloat(total.toFixed(2)),
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;
